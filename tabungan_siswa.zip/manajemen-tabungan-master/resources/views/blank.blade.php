@extends('adminlte.app')
@section('title')
Blank
@endsection